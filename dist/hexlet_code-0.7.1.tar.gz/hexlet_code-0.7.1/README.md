### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvgeniyGlibin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EvgeniyGlibin/python-project-49/actions)

<a href="https://codeclimate.com/github/EvgeniyGlibin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/76bb012a6e268f814867/maintainability" /></a>

#asciinema of the game "brain-even" 
https://asciinema.org/a/9y1qdfwymdp584a7gzhpyEAVV

#asciinema of the game "brain-calc"
https://asciinema.org/a/fNifawQY5gcwO7hfIWmz0qwE7

#asciinema of the game "brain-gcd"
https://asciinema.org/a/QWb8cSeKu4ZJ4JVHdjAfvzSDg

#asciinema of the game "brain-progression"
https://asciinema.org/a/G8hBsdA8z3XAexeKF01jz2TMC
