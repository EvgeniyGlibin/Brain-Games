def is_prime():
    print('Игра простое число')
